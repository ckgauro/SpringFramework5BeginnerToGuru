package com.gauro.demo.services;

/**
 * @author Chandra
 */
public interface GreetingService {
    String sayGreeting();
}
