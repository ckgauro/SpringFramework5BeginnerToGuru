package com.gauro.demo.services;

/**
 * @author Chandra
 */
public interface PetService {
    String getPetType() ;
}
