package com.gauro.SpringFramework5Example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFramework5ExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
